--PROGRAMMED BY MRAHMED

--VARS
local screenW, screenH = guiGetScreenSize()
local openSans = dxCreateFont(":interface/fonts/openSans.ttf", 12)
local openSans2 = dxCreateFont(":interface/fonts/openSans.ttf", 17)
local x,y = screenW - 214 - 10, 50
local timeShow = 10 -- s
local showWin, titleWim, textWin, temporary = false, false, false ,false
--TABLES
local notifs = {}
local bigWindow = {}
local types = {
	["error"] = {175,0,0,175, "icon/error.png"},
	["sucssful"] = {0,175,0,175, "icon/sucssful.png"},
	["info"] = {30,25,150,175, "icon/info.png"},
}
--FUNCTIONS
local d = dxDrawLine
function dxDrawLine(x,y,x2,y2,color, width, postGUI)
	d(x,y,x2,y2,color, width, postGUI)
	local r = bitExtract ( color, 0, 8 ) 
	local g = bitExtract ( color, 8, 8 ) 
	local b = bitExtract ( color, 16, 8 ) 
	local a = bitExtract ( color, 24, 8 )
	if y == y2 then
		for i = 1, (x2-x) / 2 do
			d(x, y,x2 - ((x2-x) / 2) - i, y2, tocolor(0,0,0,2), width, postGUI)
		end
	end
	if x == x2 then
		for i = 1, (y2-y) / 2 do
			d(x, y,x2, y2 - ((y2-y) / 2) - i, tocolor(0,0,0,2), width, postGUI)
		end
	end
end
function roundedRectangle(x, y, w, h, borderColor, bgColor, postGUI)
	if (x and y and w and h) then
		if (not borderColor) then
			borderColor = tocolor(0, 0, 0, 200);
		end
		
		if (not bgColor) then
			bgColor = borderColor;
		end
		
		--> Background
		dxDrawRectangle(x, y, w, h, bgColor, postGUI);
		
		--> Border
		dxDrawRectangle(x + 2, y - 1, w - 4, 1, borderColor, postGUI); -- top
		dxDrawRectangle(x + 2, y + h, w - 4, 1, borderColor, postGUI); -- bottom
		dxDrawRectangle(x - 1, y + 2, 1, h - 4, borderColor, postGUI); -- left
		dxDrawRectangle(x + w, y + 2, 1, h - 4, borderColor, postGUI); -- right
	end
end
function dxDrawRoundedRectangle(x,y,width,height,raduis,color,postgui)

	dxDrawRectangle(x,y+raduis,width+1,height,color,postgui)--horezantal rectangle
	dxDrawRectangle(x+raduis,y,width-(raduis*2),height+1,color,postgui)--vertical rectangle

	for k=180,270 do--left top
		local co=math.cos(math.rad(k))* raduis
		local si=math.sin(math.rad(k))* raduis
		dxDrawLine((x+raduis)+co,(y+raduis)+si,x+raduis,y+raduis,color,1,postgui)
	end
	for k=270,360 do--right top
		local co=math.cos(math.rad(k))* raduis
		local si=math.sin(math.rad(k))* raduis
		dxDrawLine((x+width-raduis)+co,(y+raduis)+si,x+width-raduis,y+raduis,color,1,postgui)
	end
end
function drawNotif()
	marginY = 0
	for i, notif in ipairs(notifs) do
		local type = notif["type"]
		local tick = notif["tick"]
		local ticknow = getTickCount()
		local texts = notif["texts"]
		local width = 0
		local height = 0
		local fontHeight = dxGetFontHeight(1, openSans)
		local colors = types[type]
		for i, text in ipairs(texts) do
			width = math.max(dxGetTextWidth(text, 1, openSans), width)
			height = height + fontHeight
		end
		local screenW = interpolateBetween(screenW + width +5, 0, 0, screenW, 0, 0, (getTickCount( ) - tick) / ((tick + 1000) - tick), "OutElastic")
		height = math.max(height, 42) + 2
		dxDrawRectangle(screenW - width - 15, marginY + 50, width + 10, height, tocolor(0,0,0,255))
		
		marginYText = 0 + marginY
		if #texts == 1 then
			marginYText = marginYText + height /2 - fontHeight / 2
		end
		for i, textS in ipairs(texts) do
			dxDrawText(textS, screenW - width - 15, 50 + marginYText, screenW - 5, 50 + marginYText + fontHeight, tocolor(255,255,255,255),1,openSans, "center", "top", false, false, false, true)
			marginYText = marginYText + fontHeight
		end
		dxDrawRectangle(screenW - width - 15 - 36, marginY + 50, 36, height, tocolor(25,25,25,255))
		dxDrawLine(screenW - width - 15 - 36, marginY + 50 + height, screenW - 5, marginY + 50 + height, tocolor(colors[1], colors[2], colors[3]), 2)
		dxDrawImage(screenW - width - 15 - 33, marginY + (height /2) + 32, 32, 32, colors[5])
		--
		marginY = marginY + height + 5
		if ( ticknow - tick >= timeShow * 1000 ) then 
			table.remove( notifs, i ) 
		end
	end
end
addEventHandler("onClientRender", root, drawNotif)

-- addNotif("Error", text1, text2,text3)
function addNotif(type, ...)
	if not type or type == "" or not types[type] then 
		type = "sucssful"
	end
	local texts = {...}
	if not texts or #texts == 0 then
		return false
	end
	local index = table.maxn(notifs) + 1
	 notifs[index] = {}
	 notifs[index]["texts"] = {}
	--
		for i, text in ipairs(texts) do
			table.insert(notifs[index]["texts"], text)
		end
		 notifs[index]["type"] = type
		 notifs[index]["tick"] = getTickCount( ) 
	--
end
addEvent("Notif:add", true)
addEventHandler("Notif:add", root, addNotif)
function drawWindow()
	if showWin then
		local fontHeight = dxGetFontHeight(1, openSans)
		local height = 0
		local marginY = 0
		local width2 = dxGetTextWidth(titleWin, 1, openSans2)
		for i,text in ipairs(textWin) do
			width2 = math.max(dxGetTextWidth(text, 1, openSans), width2)
			height = fontHeight + height
		end
		local screenW = interpolateBetween(screenW + width2, 0, 0, screenW, 0, 0, (getTickCount( ) - tickWin) / ((tickWin + 1000) - tickWin), "OutElastic")
		for i,text in ipairs(textWin) do
			dxDrawText(text, screenW - width2 - 15, 95 + marginY, screenW - 15, 95 + marginY + fontHeight, tocolor(255,255,255,255),1,openSans,"center","center",false,false,true,true)
			marginY = marginY + fontHeight 
		end
		dxDrawRectangle(screenW - width2 - 20,50 + 40,width2 + 10,height + fontHeight, tocolor(0,0,0,200))
		dxDrawRectangle(screenW - width2 - 20,50,width2 + 10,40, tocolor(25,25,25, 225))
		dxDrawText(titleWin, screenW - width2 - 15,50,screenW - width2 - 15 + width2,50 + 40, tocolor(255,255,255,255),1,openSans2, "center", "center", false,false,false,true)
		if ( getTickCount() - tickWin >= 7000 ) and temporary then 
			showWin, titleWim, textWin = false, false, false
		end
	end
end
addEventHandler("onClientRender", root, drawWindow)
function makeWindow(temporaryA, title, ...)
	local index = table.maxn(bigWindow) + 1
	showWin = true
	textWin = {...}
	titleWin = title
	tickWin = getTickCount()
	temporary = temporaryA
end
function endWindow()
	showWin, titleWim, textWin, temporary = false, false, false ,false
end
--EVENTS

fileDelete("c_notif.lua")